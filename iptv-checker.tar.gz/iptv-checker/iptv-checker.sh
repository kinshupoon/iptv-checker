#!/bin/bash
logger -s -t "【酒店电信电视ip检测】" "start"
dir=$(cd $(dirname $0); pwd)

function check_url()
{
	ck_url=$1
	ck_name=$2
	time_expire=$3
	for i in {1, 2, 3}
	do
		res_url=`curl -o /dev/null -s -w "%{time_namelookup}\t%{time_connect}\t%{time_starttransfer}\t%{time_total}\t%{speed_download}\t%{http_code}\n" --max-time 1 "$1"`

		time_namelookup=`echo $res_url | awk '{print $1}'`
		time_connect=`echo $res_url | awk '{print $2}'`
		time_starttransfer=`echo $res_url | awk '{print $3}'`
		time_total=`echo $res_url | awk '{print $4}'`
		speed_download=`echo $res_url | awk '{print $5}'`
		http_code=`echo $res_url | awk '{print $6}'`
		if [ `expr $time_total \< $time_expire` -eq 1 ]
		then
			break
		fi
	done

	if [ ! "$http_code" == "200" ] || [ `expr $time_total \> $time_expire` -eq 1 ]
	then 
		echo -e "\033[31m-- [Failed ] $time_namelookup\t$time_connect\t$time_starttransfer\t$time_total\t$speed_download\t$http_code\033[0m"
		echo -e "\033[31m--     $ck_name\033[0m"
		echo -e "\033[31m--     $ck_url\033[0m"
		return 1
	else
		echo -e "\033[33m++ [Success] $time_namelookup\t$time_connect\t$time_starttransfer\t$time_total\t$speed_download\t$http_code\033[0m"
		echo -e "\033[33m++     $ck_name\033[0m"
		echo -e "\033[33m++     $ck_url\033[0m"
		return 0
	fi
}

if [ -d ""$dir"/output" ]; then
	rm  -rf "$dir"/output
fi
mkdir -p "$dir"/output

m3u_all="$dir"/"all_online.m3u"
if [ -f "$m3u_all" ]; then
	rm $m3u_all -f
fi	

cat "$dir"/酒店电信ip测试.m3u | while read line
do
	url_pre=${line%%:*}
	if [ ! "$url_pre" = "#EXTINF" ] && [ ! "$url_pre" = "http" ]
	then
		continue;
	fi

	# 读取信息描述
	if [ "$url_pre" = "#EXTINF" ]
	then
		m3u_info="$line"
		continue
	fi

	# 读取URL
	if [ "$url_pre" = "http" ]
	then
		m3u_url=$line
	fi

	# 获取TV名称
	m3u_name="all"
	if [ -n "$m3u_info" ]
	then
		 m3u_name=`echo ${m3u_info#*,} | sed 's/[\[\/\\\|\?\"\*\:\<\>\.]//g' | sed 's/\]//g'`
	fi

	m3u_file=""$dir"/output/$m3u_name.m3u"
	# 检查URL
	check_url "$m3u_url" "$m3u_info" 0.2

	if [ $? = 0 ]
	then
		if [ -n "$m3u_info" ]; then
			echo "$m3u_info" >> "$m3u_file"
			echo "$m3u_info" >> "$m3u_all"
		fi

		echo "$m3u_url" >> "$m3u_file"
		echo "$m3u_url" >> "$m3u_all"
	fi

   m3u_info=""
   m3u_url=""
done

#----------------------------------------------------------------------------------------------------------------------------------------
sleep 10
function update_IP {
        recordIP=$(curl -s -X GET "https://api.cloudflare.com/client/v4/zones/${zone_ID}/dns_records?type=${domian_type}&name=${domian}" \
              -H "Authorization: Bearer $API_Tokens" \
              -H "Content-Type:application/json")
        Record_Info_Success=$(echo $recordIP | sed -e "s/ //g" | grep -o "success\":[a-z]*,"|awk -F : '{print $2}'|grep -o "[a-z]*")
        if [[ $Record_Info_Success != "true" ]]; then
		logger -s -t "连接Cloudflare失败，请检查 Cloudflare_Zone_ID 和 Cloudflare_API_Tokens 设置是否正确!" 
		exit 1;
        fi

        RECORD_ID=$(echo $recordIP | sed -e "s/ //g" | sed -e "s/"'"ttl":'"/"' \n '"/g" | grep "type\":\"$domian_type\"" | grep ",\"name\":\"$domian\"" | grep -o "\"id\":\"[0-9a-z]\{32,\}\",\"" | awk -F : '{print $2}'|grep -o "[a-z0-9]*")

        if [ -z "$RECORD_ID" ]; then
 		# 没有记录时新增一个域名
                  Create_Record_Api=https://api.cloudflare.com/client/v4/zones/${zone_ID}/dns_records
 		Record_Info=$(curl -s -X POST "$Create_Record_Api" -H "Authorization: Bearer $API_Tokens" -H "Content-Type:application/json" --data "{\"type\":\"$domian_type\",\"name\":\"$domian\",\"content\":\"$new_ip\",\"proxied\":$Record_Proxy}")
        else
		# 有记录时更新域名的 IP 地址
		Update_Record_Api="https://api.cloudflare.com/client/v4/zones/${zone_ID}/dns_records/${RECORD_ID}";
		Record_Info=$(curl -s -X PUT "$Update_Record_Api" -H "Authorization: Bearer $API_Tokens" -H "Content-Type:application/json" --data "{\"type\":\"$domian_type\",\"name\":\"$domian\",\"content\":\"$new_ip\",\"proxied\":$Record_Proxy}")
        fi

        #检测域名是否更新成功
        Record_Info_Success=$(echo $Record_Info | sed -e "s/ //g" | grep -o "success\":[a-z]*,"|awk -F : '{print $2}'|grep -o "[a-z]*")
        echo $Record_Info > "$dir"/info.txt
        if [[ $Record_Info_Success == "true" ]]; then
             logger -s -t "【酒店电信ip_"${domian:7:1}" DDNS】" "开始更新 "$domian" 域名 IP "
             logger -s -t "【酒店电信ip_"${domian:7:1}" DDNS】" "目前 IP: $new_ip"
             logger -s -t "【酒店电信ip_"${domian:7:1}" DDNS】" "上次 IP: $old_ip"
        else
             logger -s -t "【酒店电信ip_"${domian:7:1}" DDNS】域名更新失败!" "请检查"
        fi
}


#以下需手工填写/修改的内容已标注中文解释
zone_ID="6044a90a24ac2e5b92e9014d45fb3843"        #【区域ID】在cf相应的域名概述右下角处获取
email="1062253873@qq.com"        #Cloudflare登陆邮箱
API_Tokens="6pr4wV0xAC_2kVHlswtktg3FfgwiBT-gK7KmBw9L"        #Cloudflare API Tokens 获取地址https://dash.cloudflare.com/profile/api-tokens，自行创建相应权限
domian_type="A"        #解析记录类型 A=ipv4 AAAA=ipv6 等
ttl="1"       #解析记录生存时间，值为 1 则是自动，单位：秒
Record_Proxy=false   #true/false 开启/关闭小云朵

#------------------------------------------------------------------------------------------------------------------------------

domian="telecom1.hipjs.eu.org"        #需更新的子域名
new_ip=$(cat "$dir"/output/电信.m3u|grep -o -E [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+|sed -n '1p')
old_ip=$(nslookup $domian | tail -n 1 | awk '{print $3}')
o_ip=$(cat "$dir"/output/电信.m3u|grep -o "$old_ip")
if [ "$o_ip" == "$old_ip" ];then
    logger -s -t "【酒店电信ip_1 DDNS】" "IP 无变化！"
else
    update_IP
fi

#------------------------------------------------------------------------------------------------------------------------------

domian="telecom2.hipjs.eu.org"        #需更新的子域名
new_ip=$(cat "$dir"/output/电信.m3u|grep -o -E [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+|sed -n '2p')
old_ip=$(nslookup $domian | tail -n 1 | awk '{print $3}')
o_ip=$(cat "$dir"/output/电信.m3u|grep -o "$old_ip")
if [ "$o_ip" == "$old_ip" ];then
    logger -s -t "【酒店电信ip_2 DDNS】" "IP 无变化！"
else
    update_IP
fi

#------------------------------------------------------------------------------------------------------------------------------

domian="telecom3.hipjs.eu.org"        #需更新的子域名
new_ip=$(cat "$dir"/output/电信.m3u|grep -o -E [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+|tail -n 1)
old_ip=$(nslookup $domian | tail -n 1 | awk '{print $3}')
o_ip=$(cat "$dir"/output/电信.m3u|grep -o "$old_ip")
if [ "$o_ip" == "$old_ip" ];then
    logger -s -t "【酒店电信ip_3 DDNS】" "IP 无变化！"
else
    update_IP
fi
###################################################################################################################################
logger -s -t "【酒店联通电视ip检测】" "start"
function check_url()
{
	ck_url=$1
	ck_name=$2
	time_expire=$3
	for i in {1, 2, 3}
	do
		res_url=`curl -o /dev/null -s -w "%{time_namelookup}\t%{time_connect}\t%{time_starttransfer}\t%{time_total}\t%{speed_download}\t%{http_code}\n" --max-time 1 "$1"`

		time_namelookup=`echo $res_url | awk '{print $1}'`
		time_connect=`echo $res_url | awk '{print $2}'`
		time_starttransfer=`echo $res_url | awk '{print $3}'`
		time_total=`echo $res_url | awk '{print $4}'`
		speed_download=`echo $res_url | awk '{print $5}'`
		http_code=`echo $res_url | awk '{print $6}'`
		if [ `expr $time_total \< $time_expire` -eq 1 ]
		then
			break
		fi
	done

	if [ ! "$http_code" == "200" ] || [ `expr $time_total \> $time_expire` -eq 1 ]
	then 
		echo -e "\033[31m-- [Failed ] $time_namelookup\t$time_connect\t$time_starttransfer\t$time_total\t$speed_download\t$http_code\033[0m"
		echo -e "\033[31m--     $ck_name\033[0m"
		echo -e "\033[31m--     $ck_url\033[0m"
		return 1
	else
		echo -e "\033[33m++ [Success] $time_namelookup\t$time_connect\t$time_starttransfer\t$time_total\t$speed_download\t$http_code\033[0m"
		echo -e "\033[33m++     $ck_name\033[0m"
		echo -e "\033[33m++     $ck_url\033[0m"
		return 0
	fi
}

if [ -d "output2" ]; then
	rm "$dir"/output2 -rf
fi
mkdir -p "$dir"/output2

m3u_all="$dir"/"all_online.m3u"
if [ -f $m3u_all" ]; then
	rm $m3u_all -f
fi	

cat "$dir"/酒店联通ip测试.m3u | while read line
do
	url_pre=${line%%:*}
	if [ ! "$url_pre" = "#EXTINF" ] && [ ! "$url_pre" = "http" ]
	then
		continue;
	fi

	# 读取信息描述
	if [ "$url_pre" = "#EXTINF" ]
	then
		m3u_info="$line"
		continue
	fi

	# 读取URL
	if [ "$url_pre" = "http" ]
	then
		m3u_url=$line
	fi

	# 获取TV名称
	m3u_name="all"
	if [ -n "$m3u_info" ]
	then
		 m3u_name=`echo ${m3u_info#*,} | sed 's/[\[\/\\\|\?\"\*\:\<\>\.]//g' | sed 's/\]//g'`
	fi

	m3u_file=""$dir"/output2/$m3u_name.m3u"
	
	# 检查URL
	check_url "$m3u_url" "$m3u_info" 0.2

	if [ $? = 0 ]
	then
		if [ -n "$m3u_info" ]; then
			echo "$m3u_info" >> "$m3u_file"
			echo "$m3u_info" >> "$m3u_all"
		fi

		echo "$m3u_url" >> "$m3u_file"
		echo "$m3u_url" >> "$m3u_all"
	fi

   m3u_info=""
   m3u_url=""
done

#----------------------------------------------------------------------------------------------------------------------------------------
sleep 10
function update_IP {
        recordIP=$(curl -s -X GET "https://api.cloudflare.com/client/v4/zones/${zone_ID}/dns_records?type=${domian_type}&name=${domian}" \
              -H "Authorization: Bearer $API_Tokens" \
              -H "Content-Type:application/json")
        Record_Info_Success=$(echo $recordIP | sed -e "s/ //g" | grep -o "success\":[a-z]*,"|awk -F : '{print $2}'|grep -o "[a-z]*")
        if [[ $Record_Info_Success != "true" ]]; then
		logger -s -t "连接Cloudflare失败，请检查 Cloudflare_Zone_ID 和 Cloudflare_API_Tokens 设置是否正确!" 
		exit 1;
        fi

        RECORD_ID=$(echo $recordIP | sed -e "s/ //g" | sed -e "s/"'"ttl":'"/"' \n '"/g" | grep "type\":\"$domian_type\"" | grep ",\"name\":\"$domian\"" | grep -o "\"id\":\"[0-9a-z]\{32,\}\",\"" | awk -F : '{print $2}'|grep -o "[a-z0-9]*")

        if [ -z "$RECORD_ID" ]; then
 		# 没有记录时新增一个域名
                  Create_Record_Api=https://api.cloudflare.com/client/v4/zones/${zone_ID}/dns_records
 		Record_Info=$(curl -s -X POST "$Create_Record_Api" -H "Authorization: Bearer $API_Tokens" -H "Content-Type:application/json" --data "{\"type\":\"$domian_type\",\"name\":\"$domian\",\"content\":\"$new_ip\",\"proxied\":$Record_Proxy}")
        else
		# 有记录时更新域名的 IP 地址
		Update_Record_Api="https://api.cloudflare.com/client/v4/zones/${zone_ID}/dns_records/${RECORD_ID}";
		Record_Info=$(curl -s -X PUT "$Update_Record_Api" -H "Authorization: Bearer $API_Tokens" -H "Content-Type:application/json" --data "{\"type\":\"$domian_type\",\"name\":\"$domian\",\"content\":\"$new_ip\",\"proxied\":$Record_Proxy}")
        fi

        #检测域名是否更新成功
        Record_Info_Success=$(echo $Record_Info | sed -e "s/ //g" | grep -o "success\":[a-z]*,"|awk -F : '{print $2}'|grep -o "[a-z]*")
        echo $Record_Info > "$dir"/info2.txt
        if [[ $Record_Info_Success == "true" ]]; then
             logger -s -t "【酒店联通ip_"${domian:6:1}" DDNS】" "开始更新 "$domian" 域名 IP "
             logger -s -t "【酒店联通ip_"${domian:6:1}" DDNS】" "目前 IP: $new_ip"
             logger -s -t "【酒店联通ip_"${domian:6:1}" DDNS】" "上次 IP: $old_ip"
        else
             logger -s -t "【酒店联通ip_"${domian:6:1}" DDNS】域名更新失败!" "请检查"
        fi
}


#以下需手工填写/修改的内容已标注中文解释
zone_ID="6044a90a24ac2e5b92e9014d45fb3843"        #【区域ID】在cf相应的域名概述右下角处获取
email="1062253873@qq.com"        #Cloudflare登陆邮箱
API_Tokens="6pr4wV0xAC_2kVHlswtktg3FfgwiBT-gK7KmBw9L"        #Cloudflare API Tokens 获取地址https://dash.cloudflare.com/profile/api-tokens，自行创建相应权限
domian_type="A"        #解析记录类型 A=ipv4 AAAA=ipv6 等
ttl="1"       #解析记录生存时间，值为 1 则是自动，单位：秒
Record_Proxy=false   #true/false 开启/关闭小云朵

#------------------------------------------------------------------------------------------------------------------------------

domian="unicom1.hipjs.eu.org"        #需更新的子域名
new_ip=$(cat "$dir"/output2/联通.m3u|grep -o -E [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+|sed -n '1p')
old_ip=$(nslookup $domian | tail -n 1 | awk '{print $3}')
o_ip=$(cat "$dir"/output2/联通.m3u|grep -o "$old_ip")
if [ "$o_ip" == "$old_ip" ];then
    logger -s -t "【酒店联通ip_"${domian:6:1}" DDNS】" "IP 无变化！"
else
    update_IP
fi

#------------------------------------------------------------------------------------------------------------------------------

domian="unicom2.hipjs.eu.org"        #需更新的子域名
new_ip=$(cat "$dir"/output2/联通.m3u|grep -o -E [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+|sed -n '2p')
old_ip=$(nslookup $domian | tail -n 1 | awk '{print $3}')
o_ip=$(cat "$dir"/output2/联通.m3u|grep -o "$old_ip")
if [ "$o_ip" == "$old_ip" ];then
    logger -s -t "【酒店联通ip_"${domian:6:1}" DDNS】" "IP 无变化！"
else
    update_IP
fi

#------------------------------------------------------------------------------------------------------------------------------

domian="unicom3.hipjs.eu.org"        #需更新的子域名
new_ip=$(cat "$dir"/output2/联通.m3u|grep -o -E [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+|tail -n 1)
old_ip=$(nslookup $domian | tail -n 1 | awk '{print $3}')
o_ip=$(cat "$dir"/output2/联通.m3u|grep -o "$old_ip")
if [ "$o_ip" == "$old_ip" ];then
    logger -s -t "【酒店联通ip_"${domian:6:1}" DDNS】" "IP 无变化！"
else
    update_IP
fi

###################################################################################################################################

logger -s -t "【梅州电信电视ip检测】" "start"
function check_url()
{
	ck_url=$1
	ck_name=$2
	time_expire=$3
	for i in {1, 2, 3}
	do
		res_url=`curl -o /dev/null -s -w "%{time_namelookup}\t%{time_connect}\t%{time_starttransfer}\t%{time_total}\t%{speed_download}\t%{http_code}\n" --max-time 1 "$1"`

		time_namelookup=`echo $res_url | awk '{print $1}'`
		time_connect=`echo $res_url | awk '{print $2}'`
		time_starttransfer=`echo $res_url | awk '{print $3}'`
		time_total=`echo $res_url | awk '{print $4}'`
		speed_download=`echo $res_url | awk '{print $5}'`
		http_code=`echo $res_url | awk '{print $6}'`
		if [ `expr $time_total \< $time_expire` -eq 1 ]
		then
			break
		fi
	done

	if [ ! "$http_code" == "200" ] || [ `expr $time_total \> $time_expire` -eq 1 ]
	then 
		echo -e "\033[31m-- [Failed ] $time_namelookup\t$time_connect\t$time_starttransfer\t$time_total\t$speed_download\t$http_code\033[0m"
		echo -e "\033[31m--     $ck_name\033[0m"
		echo -e "\033[31m--     $ck_url\033[0m"
		return 1
	else
		echo -e "\033[33m++ [Success] $time_namelookup\t$time_connect\t$time_starttransfer\t$time_total\t$speed_download\t$http_code\033[0m"
		echo -e "\033[33m++     $ck_name\033[0m"
		echo -e "\033[33m++     $ck_url\033[0m"
		return 0
	fi
}

if [ -d "output3" ]; then
	rm "$dir"/output3 -rf
fi
mkdir -p "$dir"/output3

m3u_all="$dir"/"all_online.m3u"
if [ -f $m3u_all" ]; then
	rm $m3u_all -f
fi	

cat "$dir"/梅州电信ip测试.m3u | while read line
do
	url_pre=${line%%:*}
	if [ ! "$url_pre" = "#EXTINF" ] && [ ! "$url_pre" = "http" ]
	then
		continue;
	fi

	# 读取信息描述
	if [ "$url_pre" = "#EXTINF" ]
	then
		m3u_info="$line"
		continue
	fi

	# 读取URL
	if [ "$url_pre" = "http" ]
	then
		m3u_url=$line
	fi

	# 获取TV名称
	m3u_name="all"
	if [ -n "$m3u_info" ]
	then
		 m3u_name=`echo ${m3u_info#*,} | sed 's/[\[\/\\\|\?\"\*\:\<\>\.]//g' | sed 's/\]//g'`
	fi

	m3u_file=""$dir"/output3/$m3u_name.m3u"
	
	# 检查URL
	check_url "$m3u_url" "$m3u_info" 0.2

	if [ $? = 0 ]
	then
		if [ -n "$m3u_info" ]; then
			echo "$m3u_info" >> "$m3u_file"
			echo "$m3u_info" >> "$m3u_all"
		fi

		echo "$m3u_url" >> "$m3u_file"
		echo "$m3u_url" >> "$m3u_all"
	fi

   m3u_info=""
   m3u_url=""
done

#----------------------------------------------------------------------------------------------------------------------------------------
sleep 10
function update_IP {
        recordIP=$(curl -s -X GET "https://api.cloudflare.com/client/v4/zones/${zone_ID}/dns_records?type=${domian_type}&name=${domian}" \
              -H "Authorization: Bearer $API_Tokens" \
              -H "Content-Type:application/json")
        Record_Info_Success=$(echo $recordIP | sed -e "s/ //g" | grep -o "success\":[a-z]*,"|awk -F : '{print $2}'|grep -o "[a-z]*")
        if [[ $Record_Info_Success != "true" ]]; then
		logger -s -t "连接Cloudflare失败，请检查 Cloudflare_Zone_ID 和 Cloudflare_API_Tokens 设置是否正确!" 
		exit 1;
        fi

        RECORD_ID=$(echo $recordIP | sed -e "s/ //g" | sed -e "s/"'"ttl":'"/"' \n '"/g" | grep "type\":\"$domian_type\"" | grep ",\"name\":\"$domian\"" | grep -o "\"id\":\"[0-9a-z]\{32,\}\",\"" | awk -F : '{print $2}'|grep -o "[a-z0-9]*")

        if [ -z "$RECORD_ID" ]; then
 		# 没有记录时新增一个域名
                  Create_Record_Api=https://api.cloudflare.com/client/v4/zones/${zone_ID}/dns_records
 		Record_Info=$(curl -s -X POST "$Create_Record_Api" -H "Authorization: Bearer $API_Tokens" -H "Content-Type:application/json" --data "{\"type\":\"$domian_type\",\"name\":\"$domian\",\"content\":\"$new_ip\",\"proxied\":$Record_Proxy}")
        else
		# 有记录时更新域名的 IP 地址
		Update_Record_Api="https://api.cloudflare.com/client/v4/zones/${zone_ID}/dns_records/${RECORD_ID}";
		Record_Info=$(curl -s -X PUT "$Update_Record_Api" -H "Authorization: Bearer $API_Tokens" -H "Content-Type:application/json" --data "{\"type\":\"$domian_type\",\"name\":\"$domian\",\"content\":\"$new_ip\",\"proxied\":$Record_Proxy}")
        fi

        #检测域名是否更新成功
        Record_Info_Success=$(echo $Record_Info | sed -e "s/ //g" | grep -o "success\":[a-z]*,"|awk -F : '{print $2}'|grep -o "[a-z]*")
        echo $Record_Info > "$dir"/info3.txt
        if [[ $Record_Info_Success == "true" ]]; then
             logger -s -t "【梅州电信ip_"${domian:7:1}" DDNS】" "开始更新 "$domian" 域名 IP "
             logger -s -t "【梅州电信ip_"${domian:7:1}" DDNS】" "目前 IP: $new_ip"
             logger -s -t "【梅州电信ip_"${domian:7:1}" DDNS】" "上次 IP: $old_ip"
        else
             logger -s -t "【梅州电信ip_"${domian:7:1}" DDNS】域名更新失败!" "请检查"
        fi
}


#以下需手工填写/修改的内容已标注中文解释
zone_ID="6044a90a24ac2e5b92e9014d45fb3843"        #【区域ID】在cf相应的域名概述右下角处获取
email="1062253873@qq.com"        #Cloudflare登陆邮箱
API_Tokens="6pr4wV0xAC_2kVHlswtktg3FfgwiBT-gK7KmBw9L"        #Cloudflare API Tokens 获取地址https://dash.cloudflare.com/profile/api-tokens，自行创建相应权限
domian_type="A"        #解析记录类型 A=ipv4 AAAA=ipv6 等
ttl="1"       #解析记录生存时间，值为 1 则是自动，单位：秒
Record_Proxy=false   #true/false 开启/关闭小云朵

#------------------------------------------------------------------------------------------------------------------------------

domian="meizhou1.hipjs.eu.org"        #需更新的子域名
new_ip=$(cat "$dir"/output3/梅州电信.m3u|grep -o -E [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+|sed -n '1p')
old_ip=$(nslookup $domian | tail -n 1 | awk '{print $3}')
o_ip=$(cat "$dir"/output3/梅州电信.m3u|grep -o "$old_ip")
if [ "$o_ip" == "$old_ip" ];then
    logger -s -t "【梅州电信ip_"${domian:7:1}" DDNS】" "IP 无变化！"
else
    update_IP
fi

